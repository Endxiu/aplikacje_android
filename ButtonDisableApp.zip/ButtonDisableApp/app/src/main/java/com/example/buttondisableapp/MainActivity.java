package com.example.buttondisableapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button buttonDisable;
    private Button buttonEnable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonDisable = findViewById(R.id.ButtonDisable);
        buttonEnable = findViewById(R.id.ButtonEnable);

        buttonDisable.setOnClickListener(new View.OnClickListener() {
            int count = 0;
            public void onClick(View v) {
                buttonDisable.setEnabled(false);
                count+=1;
                Toast.makeText(MainActivity.this,"Przycisk został wyłączony! Counter:"+ count,Toast.LENGTH_SHORT).show();
            }
        });
        buttonEnable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonDisable.setEnabled(true);
                Toast.makeText(MainActivity.this,"Przycisk został włączony!",Toast.LENGTH_SHORT).show();
            }
        });
    }
}